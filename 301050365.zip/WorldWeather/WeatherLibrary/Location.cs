﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherLibrary
{
    public class Location
    {
        public String cityID;
        public String cityName;
        public String lon;
        public String lat;
        public String country;
    }
}
