﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherLibrary
{
    public class WeatherData
    {
        public String temperature;
        public String minTemp;
        public String maxTemp;
        public String humidity;
        public String pressure;
        public string windSpeed;
        public String windName;
        public String windDirection;
        public String clouds;
        public String visibility;
        public String precipitation;
        public String weather;
        public String lastUpdate;
        public String AsString() {
            return "Temperature (C): " + temperature + "\n"
                   + "Min Temp: " + minTemp + "\n"
                   + "Max Temp: " + maxTemp + "\n"
                   + "Humidity (%): " + humidity + "\n"
                   + "Pressure (hPas): " + pressure + "\n"
                   + "Wind Speed: " + windSpeed + "\n"
                   + "Wind Name: " + windName + "\n"
                   + "Wind Direction: " + windDirection + "\n"
                   + "Clouds: " + clouds + "\n"
                   + "Visibility: " + visibility + "\n"
                   + "Precipitation: " + precipitation + "\n"
                   + "Weather: " + weather + "\n"
                   + "Last Update: " + lastUpdate;
                }
    }
}
