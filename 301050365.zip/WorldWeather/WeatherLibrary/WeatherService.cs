﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace WeatherLibrary
{
    public class WeatherService : IWeatherDataService
    {
        public static WeatherService instance = new WeatherService();
        private WeatherService() { }
        public static WeatherService getInstance() { return instance; }
        public WeatherData GetWeatherData(ref Location location)
        {
            try
            {
                String s = "";
                if(location.cityName != "")
                    s = "http://api.openweathermap.org/data/2.5/weather?q=CityName&mode=xml&appid=78b01c5d415f20b2f7fe79b3e4f12da6&units=metric".Replace("CityName", location.cityName.Replace(" ", ""));
                else if (location.cityID != "")
                    s = "http://api.openweathermap.org/data/2.5/weather?id=CityID&mode=xml&appid=78b01c5d415f20b2f7fe79b3e4f12da6&units=metric".Replace("CityID", location.cityID);
                else if (location.lon != "" && location.lat != "")
                    s = "http://api.openweathermap.org/data/2.5/weather?lon=Longitude&lat=Latitude&mode=xml&appid=78b01c5d415f20b2f7fe79b3e4f12da6&units=metric".Replace("Longitude", location.lon).Replace("Latitude", location.lat);

                WeatherData weatherData = new WeatherData();

                XDocument Weather = new XDocument();
                Weather = XDocument.Load(s);
                var v = from city in Weather.Descendants("city") select city.Attribute("id").Value;
                location.cityID = v.First();
                v = from city in Weather.Descendants("city") select city.Attribute("name").Value;
                location.cityName = v.First();
                v = from coord in Weather.Descendants("coord") select coord.Attribute("lon").Value;
                location.lon = v.First();
                v = from coord in Weather.Descendants("coord") select coord.Attribute("lat").Value;
                location.lat = v.First();
                v = from country in Weather.Descendants("country") select country.Value;
                location.country = v.First();
                
                v = from temperature in Weather.Descendants("temperature") select temperature.Attribute("value").Value;
                weatherData.temperature = v.First();
                v = from temperature in Weather.Descendants("temperature") select temperature.Attribute("min").Value;
                weatherData.minTemp = v.First();
                v = from temperature in Weather.Descendants("temperature") select temperature.Attribute("max").Value;
                weatherData.maxTemp = v.First();
                v = from humidity in Weather.Descendants("humidity") select humidity.Attribute("value").Value;
                weatherData.humidity = v.First();
                v = from pressure in Weather.Descendants("pressure") select pressure.Attribute("value").Value;
                weatherData.pressure = v.First();
                v = from speed in Weather.Descendants("speed") select speed.Attribute("value").Value;
                weatherData.windSpeed = v.First();
                v = from speed in Weather.Descendants("speed") select speed.Attribute("name").Value;
                weatherData.windName = v.First();
                v = from direction in Weather.Descendants("direction") select direction.Attribute("value").Value;
                weatherData.windDirection = v.First();
                v = from clouds in Weather.Descendants("clouds") select clouds.Attribute("name").Value;
                weatherData.clouds = v.First();
                v = from visibility in Weather.Descendants("visibility") select visibility.Attribute("value").Value;
                weatherData.visibility = v.First();
                v = from precipitation in Weather.Descendants("precipitation") select precipitation.Attribute("mode").Value;
                weatherData.precipitation = v.First();
                v = from weather in Weather.Descendants("weather") select weather.Attribute("value").Value;
                weatherData.weather = v.First();
                v = from lastupdate in Weather.Descendants("lastupdate") select lastupdate.Attribute("value").Value;
                weatherData.lastUpdate = v.First();

                return weatherData;
            }
            catch (Exception e) { throw new WeatherDataServiceException(); }
        }
    }
}
