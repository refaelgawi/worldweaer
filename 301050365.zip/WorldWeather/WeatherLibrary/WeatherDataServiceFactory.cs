﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherLibrary
{
    public class WeatherDataServiceFactory
    {
        public const int OPEN_WEATHER_MAP = 1;
        public IWeatherDataService GetWeatherDataService(int service)
        {
            switch (service)
            {
                case OPEN_WEATHER_MAP:
                    return WeatherService.getInstance();
                default:
                    return WeatherService.getInstance();
            }
        }
    }
}
