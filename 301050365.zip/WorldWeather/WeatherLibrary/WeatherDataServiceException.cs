﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherLibrary
{
    public class WeatherDataServiceException : Exception
    {
        public WeatherDataServiceException() : base("WeatherService exception. Check your spelling and your internet connection!") { }
    }
}
