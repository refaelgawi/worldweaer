﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using WeatherLibrary;

namespace Weather
{
    public partial class WorldWeather : Form
    {
        public WorldWeather()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //check if we have enough data for the search
            if (tName.Text == "" && tID.Text == "" && (tLon.Text == "" || tLat.Text == "")) return;
            try
            {
                WeatherDataServiceFactory factory = new WeatherDataServiceFactory();
                IWeatherDataService service = factory.GetWeatherDataService(WeatherDataServiceFactory.OPEN_WEATHER_MAP);
                Location location = new Location();
                location.cityName = tName.Text;
                location.cityID = tID.Text;
                location.lon = tLon.Text;
                location.lat = tLat.Text;
                location.country = "";
/* 
                String s = "http://api.openweathermap.org/data/2.5/weather?id=CityID&mode=xml&appid=78b01c5d415f20b2f7fe79b3e4f12da6".Replace("CityID", location.cityID);
                XDocument Weather = new XDocument();
                Weather = XDocument.Load(s);
                var v = from city in Weather.Descendants("city") select city.Attribute("id").Value;
                location.cityID = v.First();
                v = from city in Weather.Descendants("city") select city.Attribute("name").Value;
                location.cityName = v.First();
                v = from coord in Weather.Descendants("coord") select coord.Attribute("lon").Value;
                location.lon = v.First();
                v = from coord in Weather.Descendants("coord") select coord.Attribute("lat").Value;
                location.lat = v.First();
                v = from country in Weather.Descendants("country") select country.Value;
                location.country = v.First();
*/
                WeatherData weatherData = service.GetWeatherData(ref location);
                tName.Text = location.cityName;
                tID.Text = location.cityID;
                tLon.Text = location.lon;
                tLat.Text = location.lat;
                tCountry.Text = location.country;

                richTextBoxWeather.Text = weatherData.AsString();
            }
            catch(WeatherDataServiceException exception)
            {
                MessageBox.Show(exception.Message);
            }
            return;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void tName_Enter(object sender, EventArgs e)
        {
            tID.Text = "";
            tLon.Text = "";
            tLat.Text = "";
            tCountry.Text = "";
            richTextBoxWeather.Text = "";
        }

        private void tID_Enter(object sender, EventArgs e)
        {
            tName.Text = "";
            tLon.Text = "";
            tLat.Text = "";
            tCountry.Text = "";
            richTextBoxWeather.Text = "";
        }

        private void tLOn_Enter(object sender, EventArgs e)
        {
            tName.Text = "";
            tID.Text = "";
            tCountry.Text = "";
            richTextBoxWeather.Text = "";
        }

        private void tLat_Enter(object sender, EventArgs e)
        {
            tName.Text = "";
            tID.Text = "";
            tCountry.Text = "";
            richTextBoxWeather.Text = "";
        }
    }
}
