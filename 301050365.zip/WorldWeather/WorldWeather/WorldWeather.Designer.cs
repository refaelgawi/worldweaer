﻿namespace Weather
{
    partial class WorldWeather
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.tName = new System.Windows.Forms.TextBox();
            this.lName = new System.Windows.Forms.Label();
            this.richTextBoxWeather = new System.Windows.Forms.RichTextBox();
            this.lWeather = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.lSearch = new System.Windows.Forms.Label();
            this.lID = new System.Windows.Forms.Label();
            this.tID = new System.Windows.Forms.TextBox();
            this.lLon = new System.Windows.Forms.Label();
            this.tLon = new System.Windows.Forms.TextBox();
            this.lLat = new System.Windows.Forms.Label();
            this.tLat = new System.Windows.Forms.TextBox();
            this.lCountry = new System.Windows.Forms.Label();
            this.tCountry = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(452, 54);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 30);
            this.button1.TabIndex = 0;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tName
            // 
            this.tName.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tName.ForeColor = System.Drawing.Color.Red;
            this.tName.Location = new System.Drawing.Point(89, 87);
            this.tName.Name = "tName";
            this.tName.Size = new System.Drawing.Size(190, 32);
            this.tName.TabIndex = 2;
            this.tName.Enter += new System.EventHandler(this.tName_Enter);
            // 
            // lName
            // 
            this.lName.AutoSize = true;
            this.lName.BackColor = System.Drawing.Color.LightCyan;
            this.lName.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lName.ForeColor = System.Drawing.Color.Blue;
            this.lName.Location = new System.Drawing.Point(9, 90);
            this.lName.Name = "lName";
            this.lName.Size = new System.Drawing.Size(74, 24);
            this.lName.TabIndex = 3;
            this.lName.Text = "Name:";
            // 
            // richTextBoxWeather
            // 
            this.richTextBoxWeather.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBoxWeather.ForeColor = System.Drawing.Color.Blue;
            this.richTextBoxWeather.Location = new System.Drawing.Point(280, 195);
            this.richTextBoxWeather.Name = "richTextBoxWeather";
            this.richTextBoxWeather.Size = new System.Drawing.Size(250, 250);
            this.richTextBoxWeather.TabIndex = 5;
            this.richTextBoxWeather.Text = "";
            // 
            // lWeather
            // 
            this.lWeather.AutoSize = true;
            this.lWeather.BackColor = System.Drawing.Color.LightCyan;
            this.lWeather.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lWeather.ForeColor = System.Drawing.Color.Blue;
            this.lWeather.Location = new System.Drawing.Point(280, 168);
            this.lWeather.Name = "lWeather";
            this.lWeather.Size = new System.Drawing.Size(154, 24);
            this.lWeather.TabIndex = 7;
            this.lWeather.Text = "Weather Data:";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(452, 90);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(120, 30);
            this.button2.TabIndex = 8;
            this.button2.Text = "Exit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lSearch
            // 
            this.lSearch.AutoSize = true;
            this.lSearch.BackColor = System.Drawing.Color.LightCyan;
            this.lSearch.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lSearch.ForeColor = System.Drawing.Color.Blue;
            this.lSearch.Location = new System.Drawing.Point(10, 55);
            this.lSearch.Name = "lSearch";
            this.lSearch.Size = new System.Drawing.Size(162, 24);
            this.lSearch.TabIndex = 9;
            this.lSearch.Text = "Search City by:";
            // 
            // lID
            // 
            this.lID.AutoSize = true;
            this.lID.BackColor = System.Drawing.Color.LightCyan;
            this.lID.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lID.ForeColor = System.Drawing.Color.Blue;
            this.lID.Location = new System.Drawing.Point(10, 127);
            this.lID.Name = "lID";
            this.lID.Size = new System.Drawing.Size(37, 24);
            this.lID.TabIndex = 11;
            this.lID.Text = "ID:";
            // 
            // tID
            // 
            this.tID.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tID.ForeColor = System.Drawing.Color.Red;
            this.tID.Location = new System.Drawing.Point(89, 124);
            this.tID.Name = "tID";
            this.tID.Size = new System.Drawing.Size(190, 32);
            this.tID.TabIndex = 10;
            this.tID.Enter += new System.EventHandler(this.tID_Enter);
            // 
            // lLon
            // 
            this.lLon.AutoSize = true;
            this.lLon.BackColor = System.Drawing.Color.LightCyan;
            this.lLon.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lLon.ForeColor = System.Drawing.Color.Blue;
            this.lLon.Location = new System.Drawing.Point(10, 165);
            this.lLon.Name = "lLon";
            this.lLon.Size = new System.Drawing.Size(56, 24);
            this.lLon.TabIndex = 13;
            this.lLon.Text = "Lon:";
            // 
            // tLon
            // 
            this.tLon.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tLon.ForeColor = System.Drawing.Color.Red;
            this.tLon.Location = new System.Drawing.Point(89, 162);
            this.tLon.Name = "tLon";
            this.tLon.Size = new System.Drawing.Size(70, 32);
            this.tLon.TabIndex = 12;
            this.tLon.Enter += new System.EventHandler(this.tLOn_Enter);
            // 
            // lLat
            // 
            this.lLat.AutoSize = true;
            this.lLat.BackColor = System.Drawing.Color.LightCyan;
            this.lLat.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lLat.ForeColor = System.Drawing.Color.Blue;
            this.lLat.Location = new System.Drawing.Point(10, 203);
            this.lLat.Name = "lLat";
            this.lLat.Size = new System.Drawing.Size(49, 24);
            this.lLat.TabIndex = 15;
            this.lLat.Text = "Lat:";
            // 
            // tLat
            // 
            this.tLat.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tLat.ForeColor = System.Drawing.Color.Red;
            this.tLat.Location = new System.Drawing.Point(89, 200);
            this.tLat.Name = "tLat";
            this.tLat.Size = new System.Drawing.Size(70, 32);
            this.tLat.TabIndex = 14;
            this.tLat.Enter += new System.EventHandler(this.tLat_Enter);
            // 
            // lCountry
            // 
            this.lCountry.AutoSize = true;
            this.lCountry.BackColor = System.Drawing.Color.LightCyan;
            this.lCountry.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lCountry.ForeColor = System.Drawing.Color.Blue;
            this.lCountry.Location = new System.Drawing.Point(9, 241);
            this.lCountry.Name = "lCountry";
            this.lCountry.Size = new System.Drawing.Size(97, 24);
            this.lCountry.TabIndex = 17;
            this.lCountry.Text = "Country:";
            // 
            // tCountry
            // 
            this.tCountry.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tCountry.ForeColor = System.Drawing.Color.Red;
            this.tCountry.Location = new System.Drawing.Point(114, 238);
            this.tCountry.Name = "tCountry";
            this.tCountry.Size = new System.Drawing.Size(45, 32);
            this.tCountry.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.LightCyan;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(584, 32);
            this.label1.TabIndex = 18;
            this.label1.Text = "My Weather Finder";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // WorldWeather
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 461);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lCountry);
            this.Controls.Add(this.tCountry);
            this.Controls.Add(this.lLat);
            this.Controls.Add(this.tLat);
            this.Controls.Add(this.lLon);
            this.Controls.Add(this.tLon);
            this.Controls.Add(this.lID);
            this.Controls.Add(this.tID);
            this.Controls.Add(this.lSearch);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lWeather);
            this.Controls.Add(this.richTextBoxWeather);
            this.Controls.Add(this.lName);
            this.Controls.Add(this.tName);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "WorldWeather";
            this.Text = "WorldWeather";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tName;
        private System.Windows.Forms.Label lName;
        private System.Windows.Forms.RichTextBox richTextBoxWeather;
        private System.Windows.Forms.Label lWeather;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lSearch;
        private System.Windows.Forms.Label lID;
        private System.Windows.Forms.TextBox tID;
        private System.Windows.Forms.Label lLon;
        private System.Windows.Forms.TextBox tLon;
        private System.Windows.Forms.Label lLat;
        private System.Windows.Forms.TextBox tLat;
        private System.Windows.Forms.Label lCountry;
        private System.Windows.Forms.TextBox tCountry;
        private System.Windows.Forms.Label label1;
    }
}

